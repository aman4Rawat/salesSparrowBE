const getBaseUrl = () => {
    return "http://localhost:5000";
}

module.exports = getBaseUrl;